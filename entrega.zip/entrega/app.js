const express = require('express');
const app = express();

app.use(express.urlencoded({extended:false}));
app.use(express.json());

const dotenv = require('dotenv');
dotenv.config({ path:'./env/.env'});

app.use('/resources',express.static('public'));
app.use('/resources', express.static(__dirname+'/public'));


app.set('view engine','ejs')

const bcryptjs = require('bcryptjs');

const session = require('express-session');
app.use(session({

secret:'secret',
resave: true,
saveUninitialized: true

}));

const connection = require('./databse/db');


app.get('/',(req,res)=>{
  res.send('index');

})

app.get('/Registro',(req,res)=>{
  res.render('Registro');

})

app.get('/login',(req,res)=>{
  res.render('login');

})

app.post('/Registro', async (req,res)=>{

  const documento = req.body.documento;
  const nombre = req.body.nombre;
  const apellido = req.body.apellido;
  const correo = req.body.correo;
  const contraseña = req.body.contraseña;
  let passwordHassh = await bcryptjs.hash(contraseña, 8);
  connection.query('INSERT INTO usuario SET ?' ,{documento:documento,nombre:nombre,apellido:apellido,correo:correo,contraseña:passwordHassh}, async (error,results)=>{
    if (error) {
      console.log(error);
    }else{
      console.log('exito');
    }
  })

})

app.post('/auth',async (req,res)=>{

 const correo = req.body.correo;
 const contraseña = req.body.contraseña;
 let passwordHassh = await bcryptjs.hash(contraseña, 8);
 if (correo && contraseña) {
  connection.query('SELECT * FROM usuario WHERE correo = ?',[correo], async (error,results)=>{

    if (results.lenght == 0 || !(await bcryptjs.compare(contraseña,results[0].contraseña))) {
      res.send('Usuario y/o contraseña incorrecta');
    }else{
      res.send('LOGIN CORRECTO');
    }
  })
 }
})

app.listen(3000,(req, res)=>{
  console.log('SERVER RUNNING IN http://localhost:3000/Registro')
})





